function Header() {
  return (
    <h1 className="text-3xl font-bold text-center mt-6 text-blue-600">
      📝 My To-Do List
    </h1>
  );
}

export default Header;
