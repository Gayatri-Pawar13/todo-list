import React from "react";
import ToDoItem from "./ToDoItem";

function ToDoList({ tasks, onDelete, onToggle }) {
  return (
    <div className="mt-6 space-y-2 w-full max-w-md">
      {tasks.map((task) => (
        <ToDoItem
          key={task.id}
          task={task}
          onDelete={() => onDelete(task.id)}
          onToggle={() => onToggle(task.id)}
        />
      ))}
    </div>
  );
}

export default ToDoList;
