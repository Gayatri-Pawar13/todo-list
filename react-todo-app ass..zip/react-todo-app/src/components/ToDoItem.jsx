import React from "react";

function ToDoItem({ task, onDelete, onToggle }) {
  return (
    <div className="flex items-center justify-between bg-gray-100 p-3 rounded-md shadow-sm">
      <span
        onClick={onToggle}
        className={`cursor-pointer ${task.completed ? "line-through text-gray-500" : ""}`}
      >
        {task.text}
      </span>
      <button onClick={onDelete} className="text-red-500 hover:text-red-700 text-xl">
        ❌
      </button>
    </div>
  );
}

export default ToDoItem;
